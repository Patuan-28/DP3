<?php if (isset($component)) { $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\GuestLayout::class, ['title' => 'Welcome to '.e(config('app.name')).'']); ?>
<?php $component->withName('guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="d-flex flex-column flex-column-fluid text-center p-10 py-lg-20">
        <!--begin::Logo-->
        <a href="javascript:;" class="mb-10 pt-lg-20">
            <img alt="Logo" src="<?php echo e(asset('img/logo.png')); ?>" class="h-50px mb-5" />
        </a>
        <!--end::Logo-->
        <!--begin::Wrapper-->
        <div class="pt-lg-10">
            <!--begin::Logo-->
            <h1 class="fw-bolder fs-2qx text-dark mb-7"><?php echo e(config('app.name')); ?></h1>
            <!--end::Logo-->
            <!--begin::Message-->
            <div class="fw-bold fs-3 text-gray-400 mb-15">
                Learning Management System
            </div>
            <!--end::Message-->
            <!--begin::Action-->
            <div class="text-center">
                <a href="guru/auth" class="btn btn-lg btn-primary fw-bolder">Log in Dosen</a>
                <a href="siswa/auth" class="btn btn-lg btn-primary fw-bolder">Log in Mahasiswa</a>
            </div>
            <!--end::Action-->
        </div>
        <!--end::Wrapper-->
    </div>
 <?php if (isset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015)): ?>
<?php $component = $__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015; ?>
<?php unset($__componentOriginalc3251b308c33b100480ddc8862d4f9c79f6df015); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?><?php /**PATH D:\KULIAH\DICODING\laragon\www\akademik\resources\views/page/welcome.blade.php ENDPATH**/ ?>