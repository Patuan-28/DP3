<!DOCTYPE html>
<html lang="en">
	<!--begin::Head-->
	<?php echo $__env->make('theme.guest.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!--end::Head-->
	<!--begin::Body-->
	<body id="kt_body" class="bg-white">
		<!--begin::Main-->
		<div class="d-flex flex-column flex-root">
			<!--begin::Authentication - Signup Welcome Message -->
			<div class="d-flex flex-column flex-column-fluid bgi-position-y-bottom position-x-center bgi-no-repeat bgi-size-contain bgi-attachment-fixed" style="background-image: url(<?php echo e(asset('keenthemes/media/illustrations/progress-hd.png')); ?>)">
				<!--begin::Content-->
				<?php echo e($slot); ?>

				<!--end::Content-->
				<!--begin::Footer-->
				
				<!--end::Footer-->
			</div>
			<!--end::Authentication - Signup Welcome Message-->
		</div>
		<!--end::Main-->
		<!--begin::Javascript-->
		<?php echo $__env->make('theme.guest.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!--end::Javascript-->
	</body>
	<!--end::Body-->
</html><?php /**PATH C:\laragon\www\akademik\resources\views/theme/guest/main.blade.php ENDPATH**/ ?>