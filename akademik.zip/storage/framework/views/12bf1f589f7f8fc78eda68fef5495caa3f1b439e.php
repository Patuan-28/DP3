<!--begin::Global Javascript Bundle(used by all pages)-->
<script src="<?php echo e(asset('keenthemes/plugins/global/plugins.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('keenthemes/js/scripts.bundle.js')); ?>"></script>
<!--end::Global Javascript Bundle--><?php /**PATH D:\KULIAH\DICODING\laragon\www\akademik\resources\views/theme/guest/js.blade.php ENDPATH**/ ?>