<table class="table table-rounded table-striped border gy-7 gs-7">
    <thead>
        <tr class="fw-bold fs-6 text-gray-800 border-bottom border-gray-200">
            <th>Siswa</th>
            <th>Tanggal</th>
            <th>Status</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
        $status = $item->st;
        if($status == "h"){
            $status = "Hadir";
        }else{
            $status = "Alfa";
        }
        ?>
        <tr>
            <td><?php echo e($item->siswa->name); ?></td>
            <td><?php echo e($item->present_at->format("j F Y H:i")); ?></td>
            <td><?php echo e($status); ?></td>
            <td>
                <a href="javascript:;" onclick="load_input('<?php echo e(route('guru.attendance.edit',$item->id)); ?>');" class="btn btn-icon btn-warning"><i class="las la-edit fs-2"></i></a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo e($collection->links('theme.app.pagination')); ?><?php /**PATH C:\laragon\www\akademik\resources\views/page/guru/attendance/list.blade.php ENDPATH**/ ?>