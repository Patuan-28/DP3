<table class="table table-rounded table-striped border gy-7 gs-7">
    <thead>
        <tr class="fw-bold fs-6 text-gray-800 border-bottom border-gray-200">
            <th>Mata Kuliah</th>
            <th>Kelas</th>
            <th>Mulai</th>
            <th>Selesai</th>
            <th>Url</th>
            <th>Judul Skripsi</th>
            <th>Deskripsi Skripsi</th>
            <th>Tenggat Waktu</th>
            <th>File Skripsi</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item->nama_pelajaran); ?></td>
            <td><?php echo e($item->nama_kelas); ?> - <?php echo e($item->year); ?></td>
            <td><?php echo e($item->start_at->format("H:i")); ?> | <?php echo e($item->start_at->format("j F Y")); ?></td>
            <td><?php echo e($item->end_at->format("H:i")); ?> | <?php echo e($item->end_at->format("j F Y")); ?></td>
            <td>
                <a href="<?php echo e($item->url); ?>" target="_blank">Link Meet</a>
            </td>
            <td>
                <?php echo e($item->task->title ?? ''); ?>

            </td>
            <td>
                <?php echo e($item->task->description ??''); ?>

            </td>
            <td>
                
                <?php if($item->task): ?>
                <?php echo e($item->task->due_at->format('j F Y')); ?> - <?php echo e($item->task->due_at->format('H:i')); ?>

                <?php endif; ?>
            </td>
            <td>
                <?php if($item->task): ?>
                <a href="<?php echo e(route('siswa.task.download',$item->task->id)); ?>" class="btn btn-sm btn-primary"><i class="bi bi-download"></i> Download</a>
                <?php endif; ?>
            </td>
            <td>
                <?php if($item->st!=NULL): ?>
                    
                <?php else: ?>
                <a href="javascript:;" onclick="handle_get('<?php echo e(route('siswa.schedule.attend',$item->id)); ?>');" title="Absensi" data-bs-toggle="tooltip" data-bs-placement="top" class="btn btn-icon btn-dark"><i class="bi bi-calendar-date"></i></a>
                <?php endif; ?>    
                <a title="Upload Tugas" data-bs-toggle="tooltip" data-bs-placement="top" href="javascript:;" onclick="load_detail('<?php echo e(route('siswa.schedule.task',$item->id)); ?>');" class="btn btn-icon btn-info"><i class="bi bi-upload"></i></a>
                <a href="<?php echo e(route('siswa.attendance.index',$item->id)); ?>" class="btn btn-icon btn-warning"><i class="las la-edit fs-2"></i></a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo e($collection->links('theme.app.pagination')); ?><?php /**PATH D:\KULIAH\DICODING\laragon\www\akademik\resources\views/page/siswa/schedule/list.blade.php ENDPATH**/ ?>