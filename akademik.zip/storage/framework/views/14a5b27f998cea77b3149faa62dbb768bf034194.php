<table class="table table-rounded table-striped border gy-7 gs-7">
    <thead>
        <tr class="fw-bold fs-6 text-gray-800 border-bottom border-gray-200">
            <th>Nama Siswa</th>    
            <th>Kelas</th>
            <th>Mata Pelajaran</th>
            <th>Kehadiran</th>
            <th>Tugas</th>
            <th>Uts</th>
            <th>Uas</th>
            <th>Nilai Akhir</th>
            <th>Predikat</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <a href="<?php echo e(route('guru.raport.generatePDF')); ?>" class="btn btn-sm btn-primary"><i class="bi bi-download"></i> Export PDF</a>
        <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item->siswa->name); ?></td>
            <td><?php echo e($item->room->title); ?></td>
            <td><?php echo e($item->course->title); ?></td>
            <td><?php echo e($item->kehadiran); ?></td>
            <td><?php echo e($item->tugas); ?></td>
            <td><?php echo e($item->uts); ?></td>
            <td><?php echo e($item->uas); ?></td>
            <?php
                $total = (($item->tugas+$item->uts)+($item->uas))/3;
                if($total>=90){
                    $hasil = 'A';
                }else if($total<90 && $total>=80){
                    $hasil = 'B';
                }
                else if($total<80 && $total>=70){
                    $hasil = 'C';
                }
                else{
                    $hasil = 'D';
                }
            ?>
            <td><?php echo e(number_format($total)); ?></td>
            <td><?php echo e($hasil); ?></td>
            <td>
                <a title="Perbarui" data-bs-toggle="tooltip" data-bs-placement="top" href="javascript:;" onclick="load_input('<?php echo e(route('guru.raport.edit',$item->id)); ?>');" class="btn btn-icon btn-warning"><i class="las la-edit fs-2"></i></a>
                <a title="Hapus" data-bs-toggle="tooltip" data-bs-placement="top" href="javascript:;" onclick="handle_delete('<?php echo e(route('guru.raport.destroy',$item->id)); ?>');" class="btn btn-icon btn-danger"><i class="las la-trash fs-2"></i></a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo e($collection->links('theme.app.pagination')); ?><?php /**PATH C:\laragon\www\akademik\resources\views/page/guru/raport/list.blade.php ENDPATH**/ ?>