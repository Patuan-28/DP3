<table class="table table-rounded table-striped border gy-7 gs-7">
    <thead>
        <tr class="fw-bold fs-6 text-gray-800 border-bottom border-gray-200">
            <th>Siswa</th>    
            <th>Tugas</th>
            <th>File Tugas</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item->siswa->name); ?></td>
            <td><?php echo e($item->task->title); ?></td>
            <td>
                <a href="<?php echo e(route('guru.task.tugas',$task->id)); ?>" class="btn btn-sm btn-primary"><i class="bi bi-download"></i> Download</a>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo e($collection->links('theme.app.pagination')); ?><?php /**PATH C:\laragon\www\akademik\resources\views/page/guru/task/list.blade.php ENDPATH**/ ?>