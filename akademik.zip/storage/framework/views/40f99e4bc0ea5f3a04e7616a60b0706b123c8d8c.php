
<ul class="pagination">
    <?php if($paginator->onFirstPage()): ?>
    <?php else: ?>
    <li class="page-item previous">
        <a href="javascript:;" halaman="<?php echo e($paginator->previousPageUrl()); ?>" class="page-link paginasi">
            <i class="previous"></i>
        </a>
    </li>
    <?php endif; ?>
    <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(is_string($element)): ?>
        <li class="page-item ">
            <a href="javascript:;" class="page-link disabled">...</a>
        </li>
        <?php endif; ?>
        <?php if(is_array($element)): ?>
            <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($page == $paginator->currentPage()): ?>
                    <li class="page-item active">
                        <a href="javascript:;" class="page-link"><?php echo e($page); ?></a>
                    </li>
                <?php else: ?>
                <li class="page-item ">
                    <a halaman="<?php echo e($url); ?>" href="javascript:;" class="page-link paginasi"><?php echo e($page); ?></a>
                </li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if($paginator->hasMorePages()): ?>
    <li class="page-item next">
        <a halaman="<?php echo e($paginator->nextPageUrl()); ?>" href="javascript:;"  class="page-link paginasi">
            <i class="next"></i>
        </a>
    </li>
    <?php endif; ?>
</ul>
<?php /**PATH D:\KULIAH\DICODING\laragon\www\akademik\resources\views/theme/app/pagination.blade.php ENDPATH**/ ?>