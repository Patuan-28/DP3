<table class="table table-rounded table-striped border gy-7 gs-7">
    <thead>
        <tr class="fw-bold fs-6 text-gray-800 border-bottom border-gray-200">
            <th>Nama Siswa</th>    
            <th>Kelas</th>
            <th>Mata Pelajaran</th>
            <th>Kehadiran</th>
            <th>Tugas</th>
            <th>Uts</th>
            <th>Uas</th>
            <th>Aksi</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($item->siswa->name); ?></td>
            <td><?php echo e($item->room->title); ?></td>
            <td><?php echo e($item->course->title); ?></td>
            <td><?php echo e($item->kehadiran); ?></td>
            <td><?php echo e($item->tugas); ?></td>
            <td><?php echo e($item->uts); ?></td>
            <td><?php echo e($item->uas); ?></td>
            <td> <td><a href="<?php echo e(route('admin.raport.generatePDF',$item->id)); ?>" class="btn btn-sm btn-primary"><i class="bi bi-download"></i> Export PDF</a></td></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php echo e($collection->links('theme.app.pagination')); ?><?php /**PATH C:\laragon\www\akademik\resources\views/page/admin/raport/list.blade.php ENDPATH**/ ?>