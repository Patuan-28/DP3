<head>
    <meta charset="utf-8" />
    <title><?php echo e(config('app.name') . ': ' .$title ?? config('app.name')); ?></title>
    <meta name="author" content="Yada Ekidanta" />
	<meta name="description" content="Yada Ekidanta is a digitalization company that was formed to be a solution for the dynamics occurring in various regions of Indonesia. Along with the changing times into the era of digitalization, all sectors and problems that occur must revolutionize systems and habits to keep up with market developments and the times. With the development of this era, the level of problems, unemployment and crime has increased and people have lost their welfare in life. Yada Ekidanta is here to participate in helping resolve the dynamics that occur as a result of the changing times. And we focus on supporting digitalisation changes in every sector and in various regions." />
	<meta name="keywords" content="<?php echo e($keyword ?? ''); ?>" />
	<link rel="canonical" href="https://yadaekidanta.com" />
	<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
	<link rel="shortcut icon" href="<?php echo e(asset('img/logo.png')); ?>" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <!--begin::Fonts-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" />
    <!--end::Fonts-->
    <!--begin::Global Stylesheets Bundle(used by all pages)-->
    <link href="<?php echo e(asset('keenthemes/plugins/global/plugins.bundle.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('keenthemes/css/style.bundle.css')); ?>" rel="stylesheet" type="text/css" />
    <!--end::Global Stylesheets Bundle-->
</head><?php /**PATH C:\laragon\www\akademik\resources\views/theme/auth/head.blade.php ENDPATH**/ ?>